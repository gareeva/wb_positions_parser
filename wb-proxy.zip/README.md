# Wildberries Proxy API

Прокси-сервер Flask, который возвращает позицию артикула в поисковой выдаче Wildberries до 40 страниц.

## Эндпоинт

```
/check_wb_position?keyword=поисковый+запрос&article=123456789
```

## Пример

```
/check_wb_position?keyword=рубашка+мужская&article=237041763
```
